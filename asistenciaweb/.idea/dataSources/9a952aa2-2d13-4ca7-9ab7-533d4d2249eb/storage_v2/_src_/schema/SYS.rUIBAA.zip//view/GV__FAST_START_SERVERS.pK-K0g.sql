CREATE VIEW GV_$FAST_START_SERVERS AS
  select "INST_ID","STATE","UNDOBLOCKSDONE","PID","XID" from gv$fast_start_servers
/

