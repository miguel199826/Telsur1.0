CREATE VIEW V_$LOCKS_WITH_COLLISIONS AS
  select "LOCK_ELEMENT_ADDR" from v$locks_with_collisions
/

