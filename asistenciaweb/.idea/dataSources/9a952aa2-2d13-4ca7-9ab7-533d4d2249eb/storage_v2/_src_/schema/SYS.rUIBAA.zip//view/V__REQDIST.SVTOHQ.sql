CREATE VIEW V_$REQDIST AS
  select "BUCKET","COUNT" from v$reqdist
/

