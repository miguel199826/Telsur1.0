CREATE VIEW V_$STANDBY_EVENT_HISTOGRAM AS
  select "NAME","TIME","UNIT","COUNT","LAST_TIME_UPDATED" from v$standby_event_histogram
/

