CREATE VIEW V_$ENQUEUE_LOCK AS
  select "ADDR","KADDR","SID","TYPE","ID1","ID2","LMODE","REQUEST","CTIME","BLOCK" from v$enqueue_lock
/

