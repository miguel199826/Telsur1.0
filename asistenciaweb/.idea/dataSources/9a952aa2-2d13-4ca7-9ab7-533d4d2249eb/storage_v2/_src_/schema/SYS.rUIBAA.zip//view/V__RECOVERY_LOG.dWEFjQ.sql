CREATE VIEW V_$RECOVERY_LOG AS
  select "THREAD#","SEQUENCE#","TIME","ARCHIVE_NAME" from v$recovery_log
/

