CREATE VIEW V_$LATCHNAME AS
  select "LATCH#","NAME","HASH" from v$latchname
/

