CREATE VIEW GV_$OPTION AS
  select "INST_ID","PARAMETER","VALUE" from gv$option
/

