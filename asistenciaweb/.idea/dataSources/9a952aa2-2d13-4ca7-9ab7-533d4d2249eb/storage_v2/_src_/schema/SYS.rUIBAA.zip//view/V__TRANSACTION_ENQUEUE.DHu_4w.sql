CREATE VIEW V_$TRANSACTION_ENQUEUE AS
  select "ADDR","KADDR","SID","TYPE","ID1","ID2","LMODE","REQUEST","CTIME","BLOCK" from v$transaction_enqueue
/

