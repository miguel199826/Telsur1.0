CREATE VIEW V_$CONFIGURED_INTERCONNECTS AS
  select "NAME","IP_ADDRESS","IS_PUBLIC","SOURCE" from v$configured_interconnects
/

