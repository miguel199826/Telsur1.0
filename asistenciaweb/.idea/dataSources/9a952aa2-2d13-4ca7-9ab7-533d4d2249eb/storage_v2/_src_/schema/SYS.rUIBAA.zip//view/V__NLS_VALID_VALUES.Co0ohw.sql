CREATE VIEW V_$NLS_VALID_VALUES AS
  select "PARAMETER","VALUE","ISDEPRECATED" from v$nls_valid_values
/

