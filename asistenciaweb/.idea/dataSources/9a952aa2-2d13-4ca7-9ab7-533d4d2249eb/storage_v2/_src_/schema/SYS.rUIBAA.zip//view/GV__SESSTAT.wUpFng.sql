CREATE VIEW GV_$SESSTAT AS
  select "INST_ID","SID","STATISTIC#","VALUE" from gv$sesstat
/

